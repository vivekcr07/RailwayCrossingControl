package service;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

import dao.UserDAO;
import model.Address;
import model.User;

public class UserServiceImpl implements UserService {

	User user;
	UserDAO udao = new UserDAO();

	Scanner sc = new Scanner(System.in);

	public void addUser(int userType) {
		Address userAddress = new Address();
		user = new User();
		try {
			System.out.println("\nEnter your detaile here ");
			System.out.print("\nName : ");
			user.setName(sc.nextLine());
			System.out.print("\nEmail : ");
			user.setEmail(sc.nextLine().toLowerCase());
			System.out.print("\nPhone : ");
			user.setPhone(sc.nextLine());
			System.out.print("\nNew password : ");
			String password = sc.nextLine();
			while (true) {
				System.out.print("\nConfirm password : ");
				if (password.equals(sc.nextLine())) {
					System.out.println("\nPassword has been set successfully");
					break;
				} else {
					System.out.println("\nPassword doesn't match");
				}
			}
			user.setPassword(password);
			System.out.println("\nAddress details ");
			System.out.print("\nBuildingNumber : ");
			userAddress.setBuildingNo(sc.nextLine());
			System.out.print("\nStreet : ");
			userAddress.setStreet(sc.nextLine());
			System.out.print("\nCity : ");
			userAddress.setCity(sc.nextLine());
			user.setAddress(userAddress);

			try {
				udao.createAccount(user, userType);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (InputMismatchException ime) {
			System.out.println("\nInvalid input");
		}

	}

	public boolean isAccountExist(int userType) {
		boolean out = false;
		System.out.print("\nEmail address :");
		String email = sc.next().toLowerCase(); // email will be stored in lower cases
		System.out.print("\nPassword : ");
		String password = sc.next();
		try {
			out = udao.isAccountExist(userType, email, password);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return out;
	}
	public boolean isEmailValid(String email) {
		
		return true;
		
	}

}
